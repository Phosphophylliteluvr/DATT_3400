
class Pendulum {
  constructor(x, y, r, a, d,AA) { 
    
    // Variables used to affect the velocity,pivot,acceleration, and such. Modified from Lab Tutorials 
    
    this.pivot = createVector(x, y,);
    this.bob = createVector();
    this.r = r;
    this.angle = a;

    this.angleVelocity = AA;
    this.angleAcceleration = 0.0;
    this.damping = d; 
    
    this.gravity = 0.3;
  }

  
  move() {
    
// Modified from Lab Tutorial, Used to Influence Acceleration, Velocity, and Bob for the Pendulum Based on Daniel Shiffman's code 
      
      this.angleAcceleration = ((-1 * this.gravity) / this.r) * sin(this.angle); 

      this.angleVelocity += this.angleAcceleration; 
      this.angle += this.angleVelocity; 

      this.angleVelocity *= this.damping; 
    
    
    this.bob.set(this.r * sin(this.angle), this.r * cos(this.angle)); 
    this.bob.add(this.pivot); 
      
    

  }
  show() {
  
    //Used to change the colours gradually based on the mapped angle from each of the Pendulums. 
    let r = map(sin(frameCount * 0.01 + this.angle), -1, 1, 0, 255); 
    
    let g = map(cos(frameCount * 0.01 + this.angle), -1, 1, 0, 255); 
    
    let b = map(cos(frameCount * 0.01 + this.angle), 1, -1, 0, 255); 

  let values = color(r,g,b); 
    
    stroke(values);
    strokeWeight(2);

    //Line of the Pendulum 
    
    line(this.pivot.x, this.pivot.y, this.bob.x, this.bob.y);
    
    
    //Circle of the Pendulum
    noFill();
    
    circle(this.bob.x, this.bob.y, this.r);
  
  } 
  
  rotation(){
  push(); 
    
    //Used to translate the Bob of the Pendulum B, and to further influence it's movement 
  
    translate(pendulumB.bob.x, pendulumB.bob.y);
  
    
    pop();
  
  }
  
  
    }
  
    
    
  
