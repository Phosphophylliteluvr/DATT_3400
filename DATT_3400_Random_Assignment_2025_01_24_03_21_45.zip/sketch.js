// taken and modified from a previous assignment from DATT 2040 A5 Pendulum Assignment
// Pendulum Variables
let pendulumA;
let pendulumB; 
let pendulumC;

function preload(){
  
  randomTable = loadTable('2.5_week.csv','csv', 'header')
  
  
  
}


function setup() {
  createCanvas(800, 800);
  
  // Creating Three different Pendulums using the Pendulum Class

    
  
    
  pendulumA = new Pendulum(width/2, height/2, random(50,100), random(TWO_PI), 0.995, random(0.0, 2.0)); 
  
  pendulumB = new Pendulum(0, 0, random(50,200), random(TWO_PI), 0.975, random(0.0, 0.1)); 
  
  
  pendulumC = new Pendulum(0, 0, random(50,90), random(PI), 1.995, random(0.0, 0.1)); 
  
  
      

      
    
  
}

function draw() {
  background(10, 1);
  
  for (let i = 0; i < randomTable.getRowCount(); i ++){
    
    let radius = randomTable.getNum(i, 'mag' );
    let longitude = randomTable.getNum(i, 'longitude');
    let latitude = randomTable.getNum(i, 'latitude');
    
    let depthError = randomTable.getNum(i, 'depthError');
    
    let mag = randomTable.getNum(i, 'mag');
    
    pendulumA.a = depthError*20;
    
    pendulumA.r = radius * 20;
    
    pendulumC.r = mag;
    
    pendulumB.r = longitude;
    
    translate(latitude*20);
    
  }
  // Changing the Original Pendulum's Pivot using Cosine and Sin
    //pendulumA.pivot.x += sin(frameCount);
  
    //pendulumA.pivot.y += cos(frameCount*0.1);
    
  
      pendulumA.move();
      pendulumA.show(); 
      pendulumA.rotation();
      
  // Pendulum B's Pivots set to Pendulum A's bob
    pendulumB.pivot.set(pendulumA.bob.x, pendulumA.bob.y);
  
      pendulumB.move();
      pendulumB.show(); 
      
      pendulumB.rotation();
   
  //Pendulum C's Pivots set to Pendulum B's bob
    pendulumC.pivot.set(pendulumB.bob.x, pendulumB.bob.y);
  
      pendulumC.move();
      pendulumC.show(); 
    
      pendulumC.rotation();
  
  
    
  
}

function keyPressed() {
  // Save the canvas when a key is pressed
  saveCanvas('DATT_2040_A5:RITHIK KUMANAN', 'jpg'); 
}