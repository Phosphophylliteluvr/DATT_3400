let titleScreen = true;

let fork;
let characteranim; 
let titleback;
let charAnim2;

let mainGameFlag = false;

let font; 
let font2; 

let fade; 
let time;

let forkanim;
let backgroundD;

let startGif = false; 
let duration = 3000; 


let state1 = true; 
let state2 = false; 
let state3 = false;

let stateCounter = 0;

let selectS;

let settingS = false;
let creditS = false;

let gui;

let soundslider;
let titleS;
let countdown;

let ifMain = false; 

let songFlag = false;
let cakeanim;
let songFlag2 = false;

let countdownFin; 
let countdownTime;

let hitcount = 0;

let brightSlider;
let mc;
let beats = [];

let peakamp; 
let spectrum;

let prev = 0;
let bassline;
let misscount = 0;
let end = false;
let clapsound;

let totalNotes;
let accuracy;

let grade;

function preload(){

  characteranim =  loadImage('Assets/intro.gif');
  
  font = loadFont('Assets/Cute_Notes.ttf');
  font2 = loadFont('Assets/GentyDemo-Regular.ttf');

  fade = millis();
  
  forkanim = loadImage('Assets/Fork.gif');
  
  titleback = loadImage('Assets/changed.gif');
  
  selectS = loadSound('Assets/select.wav');
  
  settingstabs = loadImage('Assets/settingstab.png');
  
  titleS = loadSound('Assets/omori.wav');
  
   badApple = loadSound('Assets/test2.mp3');
  
  backgroundD = loadImage('Assets/backgroundDash.gif');
  
  countdown = loadImage('Assets/countD.gif');
  
  beat = loadImage('Assets/CakeB.gif');
  
  charAnim2 = loadImage('Assets/CharAnim.gif');
  charAnim3 = loadImage('Assets/hit.gif');
  
  clapsound = loadSound('Assets/clap.wav');
   
  
}


//////////////////////////////////////PRELOAD AND VARIABLES///////////////////

function setup() {
  
  createCanvas(1000, 800);
  
    peakamp = new p5.FFT(0.3, 1024);
    bassline = new p5.PeakDetect(20, 200, 0.2, 10); 
   
    
   
  
  
    gui = createGui(); 
    gui.loadStyle("Rose");
  
    soundslider = createSlider("Volume", 380, 165, 400, 50, 0, 1);
    brightSlider = createSlider("Brightness", 380, 365, 400, 50, 0, 50);
    brightSlider.val = 5;
  
  	fork = new Sprite();
	fork.image = forkanim;
  
    fork.scale = 0.3;
  
    fork.x = 390; // Position for state 0
    fork.y = 770;
    
    mc = new Sprite();
	mc.addAnimation("neutral", charAnim2);
    mc.addAnimation("hit",charAnim3);
  
  
    mc.scale = 0; 
    mc.opacity = 0;
  
  	mc.collider = 'kinetic';
  
  
   
  
  
}

//////////////////////////////////SETUP////////////

function keyPressed() {
  
  if(keyCode == LEFT_ARROW){
    selectS.play();
    
   stateCounter = (stateCounter + 1) % 3;
    
  updateFork();
   print("worked");
    
  }
  
  else if(keyCode == RIGHT_ARROW){
    
    selectS.play();
   stateCounter = (stateCounter + 2) % 3;
    
   updateFork();
   print("worked");
    
  }
  
  if(keyCode == 90 && stateCounter == 2){
    
    titleScreen = false; 
    settingS = true;
   creditS = false;
    
    fork.scale = 0;
    fork.opacity = 0;
    
    
  }
  
  if(keyCode == 90 && stateCounter == 1){
    
    titleScreen = false; 
    settingS = false;
    creditS = true;
    
    fork.scale = 0;
    fork.opacity = 0;
    
    
  }
  
   if(keyCode == 90 && stateCounter == 0){
    
    titleScreen = false; 
    settingS = false;
    creditS = false; 
     
     ifMain = true;
     
    
    fork.scale = 0;
    fork.opacity = 0;
    
    
  }
  
  else if(keyCode == ESCAPE){
    
    titleScreen = true; 
    settingS = false; 
    creditS = false;
    
    fork.scale = 0.3; 
    fork.opacity = 100;
    
    
  }
  
 
  
    
  
  
}


///////////////////////////////////////////KEYPRESSED////////////

function updateFork(){
  
  
    if (stateCounter == 0) {
    fork.x = 390; // Position for state 0
    fork.y = 770;
  } else if (stateCounter == 1) {
    fork.x = 50; // Position for state 1 (move left)
    fork.y = 770;
  } else if (stateCounter == 2){
    
    fork.x = 750; // Position for state 1 (move left)
    fork.y = 770;
    
    
  }
  
  
}

////////////////////////////FORK FUNCTION












function draw() {
  
  
  
   drawGui();
  
  if(titleScreen){
    
    title();
    
    
    
  }
  
  else if(settingS){
    
    settings();
    
    
    
  }
  else if (ifMain){
    
    mainGame();
    character();
   
    
  }
  else if(end){
    
    
    endScreen();
    
  }
  else if(creditS){
    
    credits();
    
  }
  
  
  if (titleScreen) {
    if (!titleS.isPlaying()) {
      titleS.setVolume(soundslider.val);
      titleS.loop(); 
    }
    title();
  } 
  else {
    titleS.stop(); 
  }
  
 fill(0, 0, 0, map(brightSlider.val, 0, 100, 0, 255));
   rect(0, 0, 1000, 800)

 
   peakamp.analyze();
  bassline.update(peakamp);

  if (bassline.isDetected && badApple.isPlaying()) {
    spawnBeats();
  }
}



//////////////////////////////////////////DRAW///////

function title(){
  
  songFlag = true;
  
  image(titleback, 0, 0, 1000, 800);
  
   image(characteranim, 180, 50, 600, 650);
  
  
   let endDuration = (millis() - 5) / 1000;
  
  let textOpacity = map(endDuration, 0, 5, 0, 255);
  
  //Beat Bash Font
  
  fill(255, 255, 255, textOpacity);
  textSize(150);
  textFont(font2);
  text('Beat Bash', width/9, height/2 - 20);
  
  //242, 65, 228
  
  fill(209, 136, 208, textOpacity);
  textSize(150);
  textFont(font2);
  text('Beat Bash', width/9 + 10 , height/2 - 20);
  
  
  // Begin
   fill(255, 255, 255, textOpacity - 100);
  textSize(56);
  textFont(font2);
  text('Play', width - 550, height - 10);
  
  // Settings
   fill(255, 255, 255, textOpacity - 100);
  textSize(56);
  textFont(font2);
  text('Settings', width - 200, height - 10);
  
  // Credits
   fill(255, 255, 255, textOpacity - 100);
  textSize(56);
  textFont(font2);
  text('Credits', 100, height - 10);
  
  
}

//////////////////////////////////TITLE LAYOUT///////////

function settings(){
  
 
 
  
  image(settingstabs, 0, 0, 1000, 800);
  
  fill(235, 82, 209);
  textSize(56);
  textFont(font2);
  text('Volume', 100, 200);
  
   
  fill(235, 82, 209);
  textSize(56);
  textFont(font2);
  text('Brightness', 100, 400);
  
  drawGui();
  
  let volumeValue = soundslider.valX; 
  titleS.setVolume(volumeValue);
  
  
}

//////////////////////////////////////////////SETTINGS////////////////

function credits(){
  
  image(settingstabs, 0, 0, 1000, 800);
  
  fill(255);
  textSize(40);
  textFont(font2);
  text("SONGS: BadApple", 100, 200);
  text("Lets Get Together Now!: Omori", 100, 300);
  
  text("GAME INSPO: TAIKO NO TATSUJIN", 100, 500);
  
  
  
  
}

////////////////////////////////////////////CREDITS/////////////////

function mainGame(){
  
  songFlag = false;
  mainGameFlag = true;
    
   mc.scale = 0.8;
  
   mc.x = 150 
   mc.y = 350;
  
   if (!startGif) {
        
      time = millis();
      startGif = true;
    }
  
   if(millis() - time < duration){
    
    image(backgroundD, 0, 0, width, height); 
    backgroundD.pause();
    
    
  }
    else {
      songFlag = true;
     backgroundD.play();
    image(backgroundD, 0, 0, width, height);
      mc.opacity = 1; 
      
    
  }

   if(songFlag == false){
     
     image(countdown, 160, 0, 700, 700);
     
   }
  
  if(songFlag == true && !songFlag2){
    
      badApple.play(); 
      badApple.setVolume(soundslider.val);
    
    songFlag2 = true;
    
  }
   
   
  for (let i = 0; i < beats.length; i++) {
    beats[i].run(mc.x, mc.y); 
}
  
  //modified from Dan Tapper provided example.

 // Loop through each walker (projectile) in the beats array
  for (let i = 0; i < beats.length; i++) {
    let walker = beats[i];
    
    // Check the distance between the walker and the main character
    if (p5.Vector.dist(walker.position, createVector(mc.x, walker.position.y)) < 20 && kb.presses('z')){
     
    clapsound.setVolume(0.1);
    clapsound.play();
  
     hitcount++;
      beats.splice(i, 1); 
      
     
      i--; 
    }
    else if (walker.explode()){
      
      
       beats.splice(i, 1); 
 
      i--;
      
    }
 
  if(!badApple.isPlaying() && songFlag2){
    
    end = true;
    ifMain = false;
    mainGameFlag = false;
    
  }
      
    }
  
   fill(255, 255, 255);
  textSize(40);
  textFont(font2);
  text("Hits: " + hitcount, 50, 70); // Shows hit count on the screen
 
    
  
 
}

/////////////////////////////////////////MAINGAME
  
  
function spawnBeats() {

 let x = 900; 
 let y = 420; 
  
  let newWalker = new Vehicle(x, y);
  beats.push(newWalker);
  
  misscount++;


}
  

function character(){
  
  
  if(kb.pressing('z')){
    
    mc.changeAnimation("hit"); 
    mc.animation.play();
    
    
  }
  else{
    
    mc.changeAnimation("neutral"); 
    mc.animation.play();
    
    
  }
  
  
  
  
  
}

function endScreen(){
  
  fill(255, 255, 255);
  rect(0, 0, 1000, 800);
  mc.scale = 0; 
  mc.opacity = 0;

  let totalNotes = hitcount + misscount; // Total notes that appeared
  let accuracy = totalNotes > 0 ? (hitcount / totalNotes) * 100 : 0; // Avoid division by zero

  let grade;
  if (accuracy >= 80) {
    grade = "A"; 
  } else if (accuracy >= 40) {
    grade = "B"; // Mid performance
  } else {
    grade = "C"; 
  }

  fill(0);
  textSize(70);
  textFont(font2);
  textAlign(CENTER, CENTER);
  text("Game Over!", width / 2, height / 3);
  textSize(40);
  text(`You Got a ${grade}!`, width / 2, height / 2);
  text(`Hit Count: ${hitcount}`, width / 2, height / 2 + 48);
  text(`Miss Count: ${misscount}`, width / 2, height / 2 + 102);
}






