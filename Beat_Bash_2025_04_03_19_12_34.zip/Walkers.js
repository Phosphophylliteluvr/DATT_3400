class Vehicle {
  
  //Modified Code from Lab Tutorials and DATT_2040_A6
  
  constructor(x, y) {
    this.position = createVector(x, y); // Starting position
    this.acceleration = p5.Vector.random2D();
    this.velocity = p5.Vector.random2D();
    this.maxspeed = 7; // Max speed
    this.maxforce = 0.8; // Max force to apply
    this.r = 6; // Radius
    this.birth = millis();
    
    
  }

  run(mainCharacterx, mainCharactery) {
    this.seek(mainCharacterx, mainCharactery);  // Make the vehicle seek the main character
    this.update(); // Update the vehicle's position and velocity
    this.display(); // Display the vehicle
  }

  update() {
    // Update the position and velocity
    this.velocity.add(this.acceleration); // Update velocity with acceleration
    this.velocity.limit(this.maxspeed); // Limit the speed

    this.position.add(this.velocity); // Update position based on velocity

    // Reset the acceleration after each update
    this.acceleration.mult(0);
  }

  seek(mainCharacterx, mainCharactery) {
    
    // Seeking the main character
    let target = createVector(mainCharacterx,this.position.y);
    let desired = p5.Vector.sub(target, this.position); // Desired vector pointing to the target

    desired.setMag(this.maxspeed); // Set the desired speed

    let steer = p5.Vector.sub(desired, this.velocity); // Calculate the steering force
    steer.limit(this.maxforce); // Limit the steering force

    this.applyForce(steer); // Apply the steering force
  }

  applyForce(force) {
    // Apply the force to the acceleration
    this.acceleration.add(force);
  }

  display() {
    // Display the enemy (vehicle)
    let angle = this.velocity.heading(); // Get the angle of movement
    push();
    translate(this.position.x, this.position.y);
    imageMode(CENTER);
    image(beat, 0, 0, 100, 100); // Adjust size as needed

    pop();
  }
  
  explode() {

  
  return millis() - this.birth > 2000;
  
  }
}